package com.example.zhnmqtt;

/**
 * Created by haoningzhang on 1/31/18.
 */

public class Constants {
    public static final String MQTT_BROKER_URL = "tcp://broker.hivemq.com:1883";
    public static final String PUBLISH_TOPIC = "androidkt/topic";

    public static final String CLIENT_ID = "androidkt";
}
